
setwd("C:/Users/IT24102111/Desktop/IT24102111")
branch_data <- read.table("Exercise.txt", header = TRUE, sep = ",")

head(branch_data)

str(branch_data)
#Sales_X1 → Quantitative, Ratio

#Advertising_X2 → Quantitative, Ratio

#Years_X3 → Quantitative, Ratio

boxplot(branch_data$Sales_X1,main = "Boxplot of Sales", ylab = "Sales")

# Five number summary
summary(branch_data$Advertising_X2)

# Detailed summary
summary(branch_data$Advertising_X2)

# Interquartile Range
IQR(branch_data$Advertising_X2)

# Function to detect outliers
find_outliers <- function(x) {
  q1 <- quantile(x, 0.25)
  q3 <- quantile(x, 0.75)
  iqr <- q3 - q1
  lower <- q1 - 1.5 * iqr
  upper <- q3 + 1.5 * iqr
  outliers <- x[x < lower | x > upper]
  return(outliers)
}

# Check outliers in Years
find_outliers(branch_data$Years_X3)
